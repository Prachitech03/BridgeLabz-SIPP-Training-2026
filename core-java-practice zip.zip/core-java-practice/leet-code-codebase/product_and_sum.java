import java.util.Scanner;
public class product_and_sum {
    public int subtractProductAndSum(int n) {
        int product=1;
        int sum=0;
        while(n>0){
            sum +=n%10;
            product *=n%10;
            n=n/10; 
        }
        return product-sum;
        
    }
}
